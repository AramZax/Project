import React from 'react'

const PagesLanding = () => {
  return (
    <div>pagesLanding</div>
  )
}

export default PagesLanding