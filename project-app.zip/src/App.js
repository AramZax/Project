import React from 'react'
import Routs from './routs/routs';

function App() {
  return (
    
    <Routs />
  );
}

export default App;
