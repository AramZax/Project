# Getting Started with Create React App

### start talu hamar 
### `node js unenal kompi mej`
### `mtnel henc project-app papkan cd project-app hramanov`
### `npm install`
### `npm start`
### 